import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //Declarando o arraiList
        ArrayList<Veiculo> veiculosList = new ArrayList<Veiculo>();
        //Adicionando o Vículo no array
        veiculosList.add(Veiculo.cadastra());

    }
}