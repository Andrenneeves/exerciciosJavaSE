package controllers;

public class Boleto { }
