public class Main {
    public static void main(String[] args) {
        Calculadora tela_Calc = new Calculadora();
        tela_Calc.start();
    }
}